<?php
declare(strict_types=1);

/**
 * Database configuration shared by Docker development and Hostinger production.
 * Production credentials belong in config.local.php or environment variables.
 */
$localConfigPath = __DIR__ . '/config.local.php';
$localConfig = is_file($localConfigPath) ? require $localConfigPath : [];
$localDatabase = is_array($localConfig['database'] ?? null) ? $localConfig['database'] : [];

function databaseConfigValue(string $environmentName, string $localKey, string $developmentDefault): string
{
    global $localDatabase;

    $environmentValue = getenv($environmentName);
    if ($environmentValue !== false && trim((string)$environmentValue) !== '') {
        return trim((string)$environmentValue);
    }

    $localValue = $localDatabase[$localKey] ?? null;
    if (is_string($localValue) && trim($localValue) !== '') {
        return trim($localValue);
    }

    return $developmentDefault;
}

class Connect extends PDO
{
    public function __construct()
    {
        $host = databaseConfigValue('DB_HOST', 'host', 'db');
        $port = databaseConfigValue('DB_PORT', 'port', '3306');
        $database = databaseConfigValue('DB_NAME', 'name', 'MYSQL_DATABASE');
        $username = databaseConfigValue('DB_USER', 'user', 'MYSQL_USER');
        $password = databaseConfigValue('DB_PASSWORD', 'password', 'MYSQL_PASSWORD');
        $dsn = "mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4";

        try {
            parent::__construct($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $exception) {
            error_log('Database connection failed: ' . $exception->getMessage());
            throw new RuntimeException('ไม่สามารถเชื่อมต่อฐานข้อมูลได้');
        }
    }
}
